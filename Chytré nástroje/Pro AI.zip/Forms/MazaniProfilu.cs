﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Sockets;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;
using Chytré_nástroje.Code;

namespace Chytré_nástroje.Forms
{
    public partial class MazaniProfilu : UserControl
    {
        private const string ServerIp = "10.130.136.25";
        private const int ServerPort = 8888;
        private List<UserProfile> seznamProfilu = new List<UserProfile>();

        public MazaniProfilu()
        {
            InitializeComponent();

            ProfileDetailsLabel.Text = $"UŽIVATEL: \n" +
                                       $"STAV: \n" +
                                       $"CESTA: \n" +
                                       $"SID: ";

            // Registrace události pro změnu výběru v seznamu
            ProfilesListBox.SelectedIndexChanged += ProfilesListBox_SelectedIndexChanged;

            // Výchozí stav tlačítka
            DeleteProfileButton.Enabled = false;
        }

        private async Task CommunicateWithServer(string message)
        {
            try
            {
                using (TcpClient client = new TcpClient())
                {
                    var connectTask = client.ConnectAsync(ServerIp, ServerPort);
                    if (await Task.WhenAny(connectTask, Task.Delay(3000)) != connectTask)
                    {
                        MessageBox.Show("Chyba: Server neodpovídá.", "Chyba připojení");
                        return;
                    }

                    using (NetworkStream stream = client.GetStream())
                    using (StreamWriter writer = new StreamWriter(stream) { AutoFlush = true })
                    using (StreamReader reader = new StreamReader(stream))
                    {
                        // 1. Odeslání příkazu
                        await writer.WriteLineAsync(message);

                        // 2. Čtení CELÉ odpovědi (až do uzavření streamu serverem)
                        // ReadToEndAsync je zde bezpečný, protože server po WriteLineAsync končí/zavírá using
                        string response = await reader.ReadToEndAsync();

                        if (string.IsNullOrWhiteSpace(response))
                        {
                            return;
                        }

                        // 3. Logika zpracování podle toho, co jsme poslali
                        if (message == "GetProfiles")
                        {
                            // Teď už máme v 'response' úplně celý JSON seznam
                            ZpracujJsonProfily(response);
                        }
                        else if (message.StartsWith("DeleteProfile"))
                        {
                            ZpracujOdpovedMazani(response);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Chyba: {ex.Message}");
            }
        }

        private void ZpracujJsonProfily(string json)
        {
            try
            {
                var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
                seznamProfilu = JsonSerializer.Deserialize<List<UserProfile>>(json, options);

                ProfilesListBox.DataSource = null;
                ProfilesListBox.DataSource = seznamProfilu;
                ProfilesListBox.DisplayMember = "Uzivatel";

                if (seznamProfilu == null || seznamProfilu.Count == 0)
                {
                    MessageBox.Show("Server nenašel žádné uživatelské profily.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch
            {
                MessageBox.Show($"Server vrátil neočekávanou odpověď:\n\n{json}", "Upozornění", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void ZpracujOdpovedMazani(string json)
        {
            try
            {
                // Backend vrací např: {"Success": true, "Message": "..."}
                using JsonDocument doc = JsonDocument.Parse(json);
                bool success = doc.RootElement.GetProperty("Success").GetBoolean();
                string message = doc.RootElement.GetProperty("Message").GetString();

                MessageBox.Show(message, success ? "Úspěch" : "Chyba",
                    MessageBoxButtons.OK, success ? MessageBoxIcon.Information : MessageBoxIcon.Error);
            }
            catch
            {
                MessageBox.Show($"Odpověď po mazání: {json}", "Info");
            }
        }

        private async void GetProfilesButton_Click(object sender, EventArgs e)
        {
            GetProfilesButton.Enabled = false;
            await CommunicateWithServer("GetProfiles");
            GetProfilesButton.Enabled = true;
        }

        private void ProfilesListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ProfilesListBox.SelectedItem is UserProfile vybrany)
            {
                ProfileDetailsLabel.Text = $"UŽIVATEL: {vybrany.Uzivatel}\n" +
                                           $"STAV: {vybrany.Stav}\n" +
                                           $"CESTA: {vybrany.Slozka}\n" +
                                           $"SID: {vybrany.SID}";

                // Povolit mazání pouze pokud profil není aktivní (přihlášený)
                DeleteProfileButton.Enabled = !vybrany.Stav.Contains("AKTIVNI");
            }
            else
            {
                ProfileDetailsLabel.Text = "Vyberte profil ze seznamu...";
                DeleteProfileButton.Enabled = false;
            }
        }

        private async void DeleteProfileButton_Click(object sender, EventArgs e)
        {
            if (ProfilesListBox.SelectedItem is UserProfile vybrany)
            {
                var result = MessageBox.Show(
                    $"VAROVÁNÍ: Opravdu chcete fyzicky smazat profil uživatele {vybrany.Uzivatel}?\n\n" +
                    $"Tato akce odstraní veškerá data v {vybrany.Slozka} a záznamy v registrech.",
                    "Potvrdit smazání",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning);

                if (result == DialogResult.Yes)
                {
                    DeleteProfileButton.Enabled = false;

                    // Odeslání příkazu přes TCP
                    await CommunicateWithServer($"DeleteProfile {vybrany.SID}");

                    // Krátká pauza a aktualizace seznamu
                    await Task.Delay(1000);
                    await CommunicateWithServer("GetProfiles");
                }
            }
        }
    }
}