using DocumentFormat.OpenXml.Wordprocessing;
using System.Diagnostics;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Chytr�_n�stroje
{
    public partial class Kopirovani : UserControl
    {
        public Kopirovani()
        {
            InitializeComponent();
        }
        List<string> namesList = new List<string>();
        List<string> namesCheckedList = new List<string>();

        bool isFolder = false;
        string chooseTargetFolder = string.Empty;
        string chooseFolder = string.Empty;
        string filePath = string.Empty;

        private void chooseFolderNamesButton_Click(object sender, EventArgs e)
        {
            using (var dialog = new FolderBrowserDialog())
            {
                dialog.Description = "Vyberte slo�ku";
                dialog.UseDescriptionForTitle = true;

                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    chooseTargetFolder = dialog.SelectedPath;
                }
            }
            if (Directory.Exists(chooseTargetFolder))
            {
                string[] subfolders = Directory.GetDirectories(chooseTargetFolder);
                namesList = subfolders.Select(Path.GetFileName).ToList();
                chooseFileButton.Enabled = true;
                chooseFolderButton.Enabled = true;
                ShowNames();
            }
            else
            {
                MessageBox.Show("Zvolen� slo�ka neexistuje.");
            }
        }

        public void ShowNames()
        {
            foreach (var name in namesList)
            {
                namesCheckBox.Items.Add(name);
            }
        }

        private void chooseFileButton_Click(object sender, EventArgs e)
        {
            var fileContent = string.Empty;
            filePath = string.Empty;

            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.InitialDirectory = "c:\\";
                openFileDialog.Filter = "All files (*.*)|*.*";
                openFileDialog.FilterIndex = 2;
                openFileDialog.RestoreDirectory = true;

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    filePath = openFileDialog.FileName;
                    selectedFile.Text = filePath;
                }
            }
            CopyButton.Enabled = true;
        }

        private void chooseFolderButton_Click(object sender, EventArgs e)
        {
            using (var dialog = new FolderBrowserDialog())
            {
                dialog.Description = "Vyberte slo�ku";
                dialog.UseDescriptionForTitle = true; // od .NET 6+

                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    chooseFolder = dialog.SelectedPath;
                    selectedFolder.Text = chooseFolder;
                }
                isFolder = true;
            }
            CopyButton.Enabled = true;
        }

        private async void CopyButton_Click(object sender, EventArgs e)
        {
            progressBar.Value = 0;
            progressBar.Maximum = namesList.Count;

            var namesCheckedList = namesList
            .Where(n => namesCheckBox.CheckedItems.Contains(n))
            .ToList();

            if (isFolder && checkComputer.Checked)
            {
                await Task.Run(() =>
                {
                    foreach (var name in namesCheckedList)
                    {
                        MessageBox.Show("Funguju");
                        CopyDirectory(chooseFolder, Path.Combine(chooseTargetFolder, name, "Install", Path.GetFileName(chooseFolder)));
                        this.Invoke(() => ChangeTaskBar());
                    }
                });
            }
            else if (isFolder && !checkComputer.Checked)
            {
                await Task.Run(() =>
                {
                    foreach (var name in namesCheckedList)
                    {
                        CopyDirectory(chooseFolder, Path.Combine(chooseTargetFolder, name, Path.GetFileName(chooseFolder)));
                        this.Invoke(() => ChangeTaskBar());
                    }
                });
            }
            else if(!isFolder && checkComputer.Checked)
            {
                await Task.Run(() =>
                {
                    foreach (var name in namesCheckedList)
                    {
                        string cilovaCesta = Path.Combine(chooseTargetFolder, name, "Install", Path.GetFileName(filePath));
                        File.Copy(filePath, cilovaCesta);
                        this.Invoke(() => ChangeTaskBar());
                    }
                });
            }
            else
            {
                await Task.Run(() =>
                {
                    foreach (var name in namesCheckedList)
                    {
                        string cilovaCesta = Path.Combine(chooseTargetFolder, name, Path.GetFileName(filePath));
                        File.Copy(filePath, cilovaCesta);
                        this.Invoke(() => ChangeTaskBar());
                    }
                });
            }

            MessageBox.Show("Kop�rov�n� dokon�eno");
        }

        public static void CopyDirectory(string sourceDir, string targetDir)
        {
            // Vytvo� c�lovou slo�ku, pokud neexistuje
            if (!Directory.Exists(targetDir))
            {
                Directory.CreateDirectory(targetDir);
            }

            // Zkop�ruj v�echny soubory
            foreach (string file in Directory.GetFiles(sourceDir))
            {
                string destFile = Path.Combine(targetDir, Path.GetFileName(file));
                File.Copy(file, destFile, overwrite: true);
            }

            // Rekurzivn� zkop�ruj v�echny podslo�ky
            foreach (string subDir in Directory.GetDirectories(sourceDir))
            {
                string newTargetDir = Path.Combine(targetDir, Path.GetFileName(subDir));
                CopyDirectory(subDir, newTargetDir);
            }
        }

        private void ChangeTaskBar()
        {
            progressBar.Value = progressBar.Value + ((1 / namesList.Count()));
        }

        private void Kopirovani_Load(object sender, EventArgs e)
        {
            chooseFileButton.Enabled = false;
            chooseFolderButton.Enabled = false;
            CopyButton.Enabled = false;
        }

        private void ChooseAllButton_Click(object sender, EventArgs e)
        {

            if (namesCheckBox.CheckedItems.Count < namesCheckBox.Items.Count)
            {
                for (int i = 0; i < namesCheckBox.Items.Count; i++)
                {
                    namesCheckBox.SetItemChecked(i, true);
                }
            }
            else
            {
                for (int i = 0; i < namesCheckBox.Items.Count; i++)
                {
                    namesCheckBox.SetItemChecked(i, false);
                }
            }
        }
    }
}
