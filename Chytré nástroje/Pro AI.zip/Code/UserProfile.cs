﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chytré_nástroje.Code
{
    internal class UserProfile
    {
        public string Uzivatel { get; set; }
        public string Slozka { get; set; }
        public string SID { get; set; }
        public string Stav { get; set; }
    }
}
